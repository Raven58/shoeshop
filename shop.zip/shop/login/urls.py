from django.conf.urls import url
from . import views
from django.contrib import admin
app_name = 'login'

urlpatterns = [
    url(r'^$',views.index,name='index'),
    url(r'^products/$',views.products,name='products'),
    url(r'^contact/$',views.contact,name='contact'),
    url(r'^about/$',views.about,name='about'),
    url(r'^signup/$',views.signup,name='signup'),
    url(r'^team/$',views.team,name='team'),
    url(r'^register/$',views.UserFormView.as_view(),name='register'),
    url(r'^signin/',views.signin,name='signin'),
    url(r'^logout/',views.logout,name='logout'),
    url(r'^updateproducts/',views.updateproducts,name ='updateproducts'),
    url(r'^admin_vieworders/',views.admin_vieworders,name='admin_vieworders'),
    url(r'^cart/',views.cart,name='cart'),
    url(r'^addtocart/(?P<productid>[0-9]+)/$',views.addtocart,name = 'addtocart'),
    url(r'^removecartitem/(?P<itemid>[0-9]+)/(?P<custid>[0-9]+)/$',views.removecartitem, name = 'removecartitem'),
    url(r'^placeorder/',views.placeorder,name = 'placeorder'),
    url(r'^orders/',views.orders,name = 'orders'),
    url(r'^cancelorder/(?P<orderid>[0-9]+)/$',views.cancelorder,name= 'cancelorder'),
]
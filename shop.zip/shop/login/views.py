from django.http import HttpResponse
from django.shortcuts import render,redirect
from django.template import loader
from django.contrib.auth import authenticate, login
from django.views.generic import View
from .forms import UserForm
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib import auth
from django.contrib.auth.models import User
import datetime
import MySQLdb

from django.shortcuts import render

def index(request):
    context = {'loggedin': 0}
    if request.user.is_authenticated():
        if request.user.is_superuser:
            context = {
                'loggedin': 2,
                'name': request.user.first_name,
            }
        else:
            context = {
                'loggedin': 1,
                'name': request.user.first_name,
            }
    return render(request, 'login/index.html', context)

def products(request):
    sortby = request.POST.get('optradio')
    query = "select * from product order by "
    if sortby is None:
        print('none')
        query = "select * from product;"
    else:
        print(sortby)
        query += sortby + ";"

    template = loader.get_template('login/products.html')
    db = MySQLdb.connect('localhost', 'raven', 'hobgoblin', 'shop')
    cursor = db.cursor()
    cursor.execute(query)
    entries = []

    class product_object:
        def __init__(self, id, name, quantity, description, price):
            self.id = id
            self.name = name
            self.quantity = quantity
            self.description = description
            self.price = price

    for row in cursor:
        entries.append(product_object(row[0], row[1], row[2], row[3], row[4]))
    db.close()
    context = {'loggedin': 0}
    if request.user.is_authenticated():
        context = {
            'loggedin': 1,
            'name': request.user.first_name,
        }
        if request.user.is_superuser:
            context['loggedin'] = 2
    context['products'] = entries
    return HttpResponse(template.render(context, request))

def contact(request):
    context = {'loggedin': 0}
    if request.user.is_authenticated():
        if request.user.is_superuser:
            context = {
                'loggedin': 2,
                'name': request.user.first_name,
            }
        else:
            context = {
                'loggedin': 1,
                'name': request.user.first_name,
            }
    return render(request, 'login/contact.html', context)

def about(request):
    context = {'loggedin': 0}
    if request.user.is_authenticated():
        if request.user.is_superuser:
            context = {
                'loggedin': 2,
                'name': request.user.first_name,
            }
        else:
            context = {
                'loggedin': 1,
                'name': request.user.first_name,
            }
    return render(request, 'login/about.html', context)

def signup(request):
    context = {'loggedin': 0}
    if request.user.is_authenticated():
        context = {
            'loggedin': 1,
            'name': request.user.first_name,
        }
        if request.user.is_superuser:
            context['loggedin'] = 2
    return render(request, 'login/signup.html', context)

def team(request):
    context = {'loggedin': 0}
    if request.user.is_authenticated():
        if request.user.is_superuser:
            context = {
                'loggedin': 2,
                'name': request.user.first_name,
            }
        else:
            context = {
                'loggedin': 1,
                'name': request.user.first_name,
            }
    return render(request, 'login/team.html', context)

class UserFormView(View):
    form_class = UserForm
    template_name = 'login/signup.html'

    def get(self, request):
        print("get request")
        form = self.form_class(None)
        context = {'loggedin': 0}
        if request.user.is_authenticated():
            context = {

                'loggedin': 1,
                'name': request.user.first_name,
            }
            if request.user.is_superuser:
                context['loggedin'] = 2
        context['form'] = form
        return render(request, self.template_name, context)

    def post(self, request):
        form = self.form_class(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user.set_password(password)
            user.save()

            address = request.POST.get('address')
            city = request.POST.get('city')
            state = request.POST.get('state')
            pin = request.POST.get('pin')
            phone = request.POST.get('phone')
            db = MySQLdb.connect("localhost", "raven", "hobgoblin", "shop")
            cursor = db.cursor()
            cursor.execute("select id from auth_user where username = '" + username + "';")

            userid = cursor.fetchone()
            userid = int(userid[0])
            cursor.execute(
                "insert ignore into user_address values (" + str(pin) + ",'" + str(city) + "','" + str(state) + "')")
            cursor.execute(
                "insert into users values(" + str(userid) + ",'" + str(address) + "'," + str(pin) + ",'" + str(
                    phone) + "');")

            db.commit()
            db.close()

            user = authenticate(username=username, password=password)
            if user is not None:

                if user.is_active:
                    login(request, user)
                    return redirect('login:index')
        else:
            context = {'errormessage': 2}
        context['loggedin'] = 0
        if request.user.is_authenticated():
            context['loggedin'] = 1
            context['name'] = request.user.first_name,

            if request.user.is_superuser:
                context['loggedin'] = 2
        context['form'] = form
        return render(request, self.template_name, context)

def signin(request):
    context = {'loggedin':0}
    print("check 1")
    if request.POST:
        print("check 2")
        if request.user.is_authenticated:
            print("check 3")
            context = {
                'loggedin':1,
                'errormessage': 1,
                'name': request.user.first_name,
            }
            if request.user.is_superuser:
                context['loggedin']=2
            return render(request,'login/index.html',context)
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = auth.authenticate(username=username,password=password)
        if user is not None:
            print("check 4")
            auth.login(request, user)
            if request.user.is_superuser:
                context = {'loggedin': 2}
                return render(request, 'login/index.html', context)
            context = {'loggedin':1,
                       'name':request.user.first_name,}
            return render(request,'login/index.html',context)
        else:
            messages.error(request,'Invalid username or password.')
    print("check 6")
    return render(request, 'login/index.html',context)

def logout(request):
    context = {'loggedin': 0, }
    if request.user.is_authenticated():
        auth.logout(request)
        messages.success(request, 'Successfully logged out.')
    return render(request,'login/index.html',context)

def updateproducts(request):
    context = {'loggedin': 0}
    if request.user.is_authenticated():
        if request.user.is_superuser:
            context = {
                'loggedin': 2,
                'name': request.user.first_name,
            }
        else:
            context = {
                'loggedin': 1,
                'name': request.user.first_name,
            }
    return render(request, 'login/updateproducts.html', context)

def admin_vieworders(request):
    class order_display:
        def __init__(self,orderid,customername,productnames,orderdate,cost,deliverystatus,paymentstatus,paymentdetails):
            self.orderid = orderid
            self.customername = customername
            self.productnames = productnames
            self.orderdate = orderdate
            self.cost = cost
            self.deliverystatus = deliverystatus
            self.paymentstatus = paymentstatus
            self.paymentdetails = paymentdetails

    db = MySQLdb.connect('localhost', 'raven', 'hobgoblin', 'shop')
    cursor = db.cursor()
    cursor.execute("select orders.order_id,auth_user.first_name,auth_user.last_name,orders.order_date,orders.total_cost,orders.delivery_status,orders.payment_id  from orders inner join auth_user on orders.cust_id = auth_user.id;")
    entries = cursor.fetchall()
    details = []
    for item in entries:
        cursor.execute("select status,details from payment where payment_id = "+str(item[-1])+";")
        paymentstat = cursor.fetchone()
        cursor.execute("select order_items.item_quantity, product.name from order_items inner join product on order_items.item_id = product.id  where order_items.order_id = "+str(item[0])+";")
        productsget = cursor.fetchall()
        listofproducts = ""
        for element in productsget:
            listofproducts+= str(element[1])+": "+str(element[0])+",\n"
        details.append(order_display(item[0],str(item[1])+" "+str(item[2]),listofproducts,item[3],item[4],item[5],paymentstat[0],paymentstat[1]))
    db.close()
    context={
        'loggedin':2,
        'name': request.user.first_name,
        'details': details,
    }
    return render(request,'login/admin_vieworders.html',context)

def cart(request):
    db = MySQLdb.connect('localhost', 'raven', 'hobgoblin', 'shop')
    cursor = db.cursor()
    cursor.execute(
        "select cart.item_id,cart.quantity,product.price from cart inner join product on cart.item_id = product.id where cart.cust_id = " + str(
            request.user.id) + ";")

    class cartobject:
        def __init__(self, item_id, name, description, quantity, cost_item, cust_id):
            self.item_id = item_id
            self.name = name
            self.description = description
            self.quantity = quantity
            self.cost_item = cost_item
            self.cust_id = cust_id

    cart_items = []
    entries = []
    for item in cursor:
        entries.append(item)

    final_price = 0

    for item in entries:
        cursor.execute("select name,description from product where id = " + str(item[0]) + ";")
        namedesc = cursor.fetchone()
        cart_items.append(cartobject(item[0], namedesc[0], namedesc[1], item[1], item[2], request.user.id))
        final_price += float(item[1]) * float(item[2])

    context = {
        'order_total': final_price,
        'cart_items': cart_items,
        'loggedin': 1,
        'name': request.user.first_name,
    }
    if request.user.is_superuser:
        context['loggedin'] = 2
    return render(request, 'login/cart.html', context)

def addtocart(request, productid):
    quantity = int(request.POST.get('quantity'))
    db = MySQLdb.connect("localhost", "raven", "hobgoblin", "shop")
    cursor = db.cursor()
    cursor.execute("select quantity from product where id = "+str(productid)+";")

    quantity_left = cursor.fetchone()
    quantity_left = quantity_left[0]
    if quantity_left < quantity:
        pass#show error message of stock less than required
        db.close()
        return redirect('login:products')
    else:
        cursor.execute("update product set quantity = " + str(quantity_left - quantity) + " where id = "+ str(productid) + ";")
        cursor.execute("select price from product where id = "+str(productid)+";")
        price = cursor.fetchone()
        price = price[0]
        preventries = cursor.execute("select * from cart where cust_id = "+str(request.user.id)+" and item_id="+str(productid)+";")

        if preventries == 0:
            cursor.execute( "insert into cart values(" +str(request.user.id)+","+str(productid)+","+str(quantity)+ ");" )
        else:
            cursor.execute("select quantity from cart where cust_id = "+str(request.user.id) + " and item_id = "+str(productid)+";")
            prevquantity = cursor.fetchone()
            prevquantity = prevquantity[0]
            cursor.execute("update cart set quantity = "+ str(prevquantity+quantity)+" where cust_id = "+str(request.user.id) + " and item_id = "+str(productid)+";")
        db.commit()
        db.close()
        return redirect('login:products')

def removecartitem(request,itemid,custid):
    print('removecartitem')
    db = MySQLdb.connect("localhost", "raven", "hobgoblin", "shop")
    cursor = db.cursor()
    cursor.execute("select quantity from cart where cust_id = "+str(custid) + " and item_id = "+ str(itemid) + ";")
    quantity = cursor.fetchone()
    quantity = int(quantity[0])
    cursor.execute("delete from cart where cust_id = "+str(custid) + " and item_id = "+ str(itemid) + ";")
    cursor.execute("update product set quantity = quantity + "+ str(quantity) + ";")
    db.commit()
    db.close()
    return redirect('login:cart')

def placeorder(request):
    db = MySQLdb.connect("localhost", "raven", "hobgoblin", "shop")
    cursor = db.cursor()
    id = request.user.id
    now = datetime.datetime.now()
    cursor.execute("select cart.quantity,product.price from cart inner join product on cart.item_id = product.id where cart.cust_id = "+str(id)+";")
    pricecalculate = cursor.fetchall()
    order_total = 0.0
    for item in pricecalculate:
        order_total += item[0]*item[1]
    cursor.execute("insert into payment (status,details) values (0,'');")
    cursor.execute("insert into orders (cust_id,order_date,total_cost,payment_id,delivery_status) values ("+str(id)+",CURDATE(),"+str(order_total)+",LAST_INSERT_ID(),0);")
    cursor.execute("select order_id from orders where cust_id = "+str(id)+";")
    order_id = cursor.fetchall()
    order_id = int(order_id[-1][0])
    cursor.execute("select cart.item_id,cart.quantity,product.price from cart inner join product on cart.item_id = product.id where cart.cust_id = "+str(id)+" ;")
    cart_items = cursor.fetchall()
    for item in cart_items:
        cursor.execute("insert into order_items values ("+str(order_id)+","+str(item[0])+","+str(item[1])+","+str(item[2])+");")
        cursor.execute("delete from cart where cust_id = "+str(id)+" and item_id = "+str(item[0])+";")
    db.commit()
    db.close()
    return redirect('login:orders')

def orders(request):
    class orderdisplay:
        def __init__(self,order_id, order_date, total_cost, payment_status, delivery_status):
            self.order_id = order_id
            self.order_date = order_date
            self.total_cost = total_cost
            self.payment_status = payment_status
            self.delivery_status = delivery_status

    id = request.user.id
    db = MySQLdb.connect('localhost', 'raven', 'hobgoblin', 'shop')
    cursor = db.cursor()
    cursor.execute("select * from orders where cust_id = "+str(id)+";")
    entries = cursor.fetchall()
    orderentries = []
    for item in entries:
        nowdate = item[2].strftime("%Y-%m-%d")
        cursor.execute("select status from payment where payment_id = "+str(item[5])+";")
        status = cursor.fetchone()
        status = int(status[0])
        orderentries.append(orderdisplay(item[0],nowdate,item[3],status,item[4]))

    context = {
        'order_entries': orderentries,
        'loggedin': 1,
        'name': request.user.first_name,
    }
    db.close()
    if request.user.is_superuser:
        context['loggedin']=2;
    return render(request,'login/orders.html',context)

def cancelorder(request,orderid):
    db = MySQLdb.connect('localhost', 'raven', 'hobgoblin', 'shop')
    cursor = db.cursor()
    cursor.execute("select item_id,item_quantity from order_items where order_id = "+str(orderid)+";")
    torestore = cursor.fetchall()
    for item in torestore:
        cursor.execute("update product set quantity = quantity + " + str(item[1]) + " where id = "+ str(item[0])+ ";");
    cursor.execute("delete from order_items where order_id = "+str(orderid)+";")
    cursor.execute("delete from orders where order_id = "+str(orderid)+";")
    db.commit()
    db.close()
    return redirect('login:orders')




